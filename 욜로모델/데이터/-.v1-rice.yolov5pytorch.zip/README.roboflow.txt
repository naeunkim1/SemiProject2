
밥 - v1 rice
==============================

This dataset was exported via roboflow.ai on May 31, 2022 at 9:35 AM GMT

It includes 682 images.
Rice are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Random rotation of between -15 and +15 degrees


